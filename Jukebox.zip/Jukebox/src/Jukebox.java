import java.util.ArrayList;
import java.util.List;

public class Jukebox<T> implements JukeInterface {
	public ArrayList<Record> records;
	
	public Jukebox() {
		
		records = new ArrayList<Record>();
	}
	
	@Override
	public void insert(Record aRecord) {
		// TODO Auto-generated method stub
		this.records.add(aRecord);
	}

	@Override
	public void insert(int slot, Record aRecord) {
		// TODO Auto-generated method stub
		this.records.add(slot, aRecord);
	}

	@Override
	public boolean remove(Record aRecord) {
		// TODO Auto-generated method stub
		return this.records.remove(aRecord);
	}

	@Override
	public boolean contains(Record aRecord) {
		if (this.records.contains(aRecord))
			return true;
		else
			return false;
	}

	@Override
	public int findSlot(Record aRecord) {
		return this.records.indexOf(aRecord);
	}

	@Override
	public Record random() {
		// TODO Auto-generated method stub
		return this.records.get((int)(Math.random()*records.size()));
	}
	
	public String toString() {
		return records.toString();
		}
	
}
